'use client';

import { MessageSquare, Bookmark, Trash2, ExternalLink, ArrowUp, Clock } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useFollowed } from '@/hooks/use-hn';
import { useHNStore } from '@/store/hn-store';
import { timeAgo } from '@/lib/hn-api';
import { useQueryClient } from '@tanstack/react-query';

export function FollowedPanel() {
  const { data: followed, isLoading } = useFollowed();
  const { setSelectedStoryId, addVisited } = useHNStore();
  const queryClient = useQueryClient();

  const handleUnfollow = async (storyId: number) => {
    try {
      await fetch(`/api/follow?storyId=${storyId}`, { method: 'DELETE' });
      queryClient.invalidateQueries({ queryKey: ['followed'] });
    } catch (err) {
      console.error('Failed to unfollow:', err);
    }
  };

  const handleClick = (storyId: number) => {
    setSelectedStoryId(storyId);
    addVisited(storyId);
  };

  const handleMarkRead = async (e: React.MouseEvent, storyId: number) => {
    e.stopPropagation();
    try {
      await fetch('/api/follow', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ storyId }),
      });
      queryClient.invalidateQueries({ queryKey: ['followed'] });
    } catch (err) {
      console.error('Failed to mark read:', err);
    }
  };

  const handleClearAll = async () => {
    try {
      await fetch('/api/follow', { method: 'DELETE' });
      queryClient.invalidateQueries({ queryKey: ['followed'] });
    } catch (err) {
      console.error('Failed to clear all:', err);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-3 p-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (!followed || followed.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <Bookmark className="w-12 h-12 mx-auto mb-3 opacity-30" />
        <h3 className="text-lg font-medium mb-1">No followed stories</h3>
        <p className="text-sm">Click the bookmark icon on any story to follow its comments</p>
      </div>
    );
  }

  return (
    <div className="space-y-2 p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-medium text-muted-foreground">
          {followed.length} followed {followed.length === 1 ? 'story' : 'stories'}
        </h2>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs text-destructive hover:text-destructive"
          onClick={handleClearAll}
        >
          <Trash2 className="w-3.5 h-3.5 mr-1" />
          Clear all
        </Button>
      </div>

      {followed.map((story) => (
        <Card 
          key={story.id}
          className="cursor-pointer transition-all hover:shadow-md border-l-2 border-l-orange-500"
          onClick={() => handleClick(story.storyId)}
        >
          <CardContent className="p-3 sm:p-4">
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-medium leading-snug line-clamp-2">
                  {story.title || `Story #${story.storyId}`}
                </h3>
                <div className="flex items-center flex-wrap gap-x-3 gap-y-1 mt-1.5 text-xs text-muted-foreground">
                  <span className="flex items-center gap-0.5">
                    <ArrowUp className="w-3 h-3 text-orange-500" />
                    {story.score}
                  </span>
                  <span className="flex items-center gap-0.5">
                    <MessageSquare className="w-3 h-3" />
                    {story.currentCommentCount} comments
                  </span>
                  <span className="flex items-center gap-0.5">
                    <Clock className="w-3 h-3" />
                    followed {timeAgo(Math.floor(new Date(story.followedAt).getTime() / 1000))}
                  </span>
                </div>
              </div>

              <div className="flex flex-col items-center gap-1 shrink-0">
                {story.newComments > 0 && (
                  <Badge className="bg-orange-500 hover:bg-orange-600 text-white text-[10px] px-1.5 h-5">
                    +{story.newComments} new
                  </Badge>
                )}
                <div className="flex gap-1">
                  {story.newComments > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 text-xs text-green-600 hover:text-green-700"
                      onClick={(e) => handleMarkRead(e, story.storyId)}
                      title="Mark as read"
                    >
                      <span className="text-xs">✓</span>
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUnfollow(story.storyId);
                    }}
                    title="Unfollow"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
