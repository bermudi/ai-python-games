'use client';

import { useHNStore, type StoryType } from '@/store/hn-store';
import { Flame, Clock, Trophy, HelpCircle, Monitor, Briefcase, Bookmark, Eye, EyeOff, Trash2, Settings, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { useFollowed } from '@/hooks/use-hn';
import { ThemeToggle } from './theme-toggle';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

const NAV_ITEMS: { type: StoryType; label: string; icon: React.ElementType }[] = [
  { type: 'top', label: 'Top', icon: Flame },
  { type: 'new', label: 'New', icon: Clock },
  { type: 'best', label: 'Best', icon: Trophy },
  { type: 'ask', label: 'Ask', icon: HelpCircle },
  { type: 'show', label: 'Show', icon: Monitor },
  { type: 'job', label: 'Jobs', icon: Briefcase },
];

export function Header() {
  const { storyType, setStoryType, hideVisited, setHideVisited, viewMode, setViewMode } = useHNStore();
  const { data: followed } = useFollowed();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const totalNewComments = followed 
    ? followed.reduce((sum, f) => sum + f.newComments, 0) 
    : 0;

  const handleClearVisited = async () => {
    try {
      await fetch('/api/visited', { method: 'DELETE' });
      useHNStore.getState().setVisitedIds(new Set());
      queryClient.invalidateQueries({ queryKey: ['visited'] });
      toast({ title: 'History cleared', description: 'All visited stories have been reset.' });
    } catch {
      toast({ title: 'Error', description: 'Failed to clear history.', variant: 'destructive' });
    }
  };

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-5xl mx-auto px-4">
        {/* Top bar */}
        <div className="flex items-center justify-between h-12">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 cursor-pointer" onClick={() => { setViewMode('stories'); }}>
              <div className="w-7 h-7 rounded bg-orange-500 flex items-center justify-center">
                <Flame className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-lg font-bold tracking-tight">
                HN<span className="text-orange-500">Reader</span>
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* View mode toggle */}
            <div className="flex items-center gap-0.5 bg-muted rounded-lg p-0.5">
              <Button
                variant={viewMode === 'stories' ? 'default' : 'ghost'}
                size="sm"
                className="h-7 px-2 sm:px-3 text-xs"
                onClick={() => setViewMode('stories')}
              >
                Stories
              </Button>
              <Button
                variant={viewMode === 'followed' ? 'default' : 'ghost'}
                size="sm"
                className="h-7 px-2 sm:px-3 text-xs relative"
                onClick={() => setViewMode('followed')}
              >
                <Bookmark className="w-3.5 h-3.5 sm:mr-1" />
                <span className="hidden sm:inline">Followed</span>
                {totalNewComments > 0 && (
                  <Badge variant="destructive" className="ml-1 h-4 min-w-4 px-1 text-[10px]">
                    {totalNewComments}
                  </Badge>
                )}
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6 hidden sm:block" />

            {/* Hide visited toggle (desktop) */}
            <div className="hidden sm:flex items-center gap-1.5">
              {hideVisited ? (
                <EyeOff className="w-3.5 h-3.5 text-muted-foreground" />
              ) : (
                <Eye className="w-3.5 h-3.5 text-muted-foreground" />
              )}
              <Label htmlFor="hide-visited" className="text-xs text-muted-foreground cursor-pointer">
                Hide read
              </Label>
              <Switch
                id="hide-visited"
                checked={hideVisited}
                onCheckedChange={setHideVisited}
                className="scale-75"
              />
            </div>

            <ThemeToggle />

            {/* Settings dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                  <Settings className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleClearVisited}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear read history
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => window.open('https://news.ycombinator.com', '_blank')}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Hacker News
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Navigation tabs */}
        {viewMode === 'stories' && (
          <nav className="flex items-center gap-0.5 pb-2 -mb-px overflow-x-auto scrollbar-none">
            {NAV_ITEMS.map(({ type, label, icon: Icon }) => (
              <Button
                key={type}
                variant={storyType === type ? 'secondary' : 'ghost'}
                size="sm"
                className={`h-8 px-2.5 sm:px-3 text-xs gap-1 sm:gap-1.5 shrink-0 ${
                  storyType === type 
                    ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 hover:bg-orange-500/20' 
                    : 'text-muted-foreground'
                }`}
                onClick={() => setStoryType(type)}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{label}</span>
              </Button>
            ))}
            
            {/* Mobile hide visited toggle */}
            <div className="sm:hidden flex items-center gap-1 ml-auto">
              <Button
                variant={hideVisited ? 'secondary' : 'ghost'}
                size="sm"
                className={`h-8 px-2 text-xs ${hideVisited ? 'bg-orange-500/10 text-orange-600' : 'text-muted-foreground'}`}
                onClick={() => setHideVisited(!hideVisited)}
              >
                {hideVisited ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
