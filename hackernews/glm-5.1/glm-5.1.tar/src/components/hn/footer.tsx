'use client';

import { Flame, Github } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-auto border-t bg-muted/30">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <Flame className="w-3.5 h-3.5 text-orange-500" />
          <span>HNReader — Hacker News Reader</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Data from <a href="https://news.ycombinator.com" target="_blank" rel="noopener noreferrer" className="hover:text-orange-500 transition-colors">Hacker News API</a></span>
        </div>
      </div>
    </footer>
  );
}
