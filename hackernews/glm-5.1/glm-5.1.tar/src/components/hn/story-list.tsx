'use client';

import { useStories, useVisited } from '@/hooks/use-hn';
import { useHNStore } from '@/store/hn-store';
import { StoryCard, StoryCardSkeleton } from './story-card';
import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertCircle } from 'lucide-react';

export function StoryList() {
  const { storyType, hideVisited, visitedIds, setVisitedIds, page, setPage } = useHNStore();
  const { data, isLoading, error, refetch, isRefetching } = useStories(storyType, page);
  const { data: visitedData } = useVisited();

  // Load visited IDs into store
  useEffect(() => {
    if (visitedData) {
      const ids = new Set(visitedData.map((v) => v.storyId));
      setVisitedIds(ids);
    }
  }, [visitedData, setVisitedIds]);

  const filteredStories = hideVisited
    ? data?.stories.filter((s) => !visitedIds.has(s.id))
    : data?.stories;

  if (error) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-30" />
        <h3 className="text-lg font-medium mb-1">Failed to load stories</h3>
        <p className="text-sm mb-4">Something went wrong fetching from Hacker News</p>
        <Button variant="outline" onClick={() => refetch()}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Try again
        </Button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-2 p-4">
        {Array.from({ length: 10 }).map((_, i) => (
          <StoryCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (!filteredStories || filteredStories.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <h3 className="text-lg font-medium mb-1">
          {hideVisited ? 'All stories visited!' : 'No stories found'}
        </h3>
        <p className="text-sm">
          {hideVisited ? 'Toggle "Hide read" to see all stories' : 'Try a different category'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2 p-4">
      {/* Refresh button */}
      <div className="flex justify-end">
        <Button
          variant="ghost"
          size="sm"
          className="text-xs text-muted-foreground h-7"
          onClick={() => refetch()}
          disabled={isRefetching}
        >
          <RefreshCw className={`w-3.5 h-3.5 mr-1 ${isRefetching ? 'animate-spin' : ''}`} />
          {isRefetching ? 'Refreshing...' : 'Refresh'}
        </Button>
      </div>

      {filteredStories.map((story, index) => (
        <StoryCard
          key={story.id}
          story={story}
          index={(page - 1) * 30 + index}
          onSelect={(id) => useHNStore.getState().setSelectedStoryId(id)}
        />
      ))}

      {/* Pagination */}
      <div className="flex items-center justify-center gap-2 pt-4 pb-2">
        {page > 1 && (
          <Button variant="outline" size="sm" onClick={() => setPage(page - 1)}>
            Previous
          </Button>
        )}
        <span className="text-xs text-muted-foreground">Page {page}</span>
        {data && data.stories.length === 30 && (
          <Button variant="outline" size="sm" onClick={() => setPage(page + 1)}>
            Next
          </Button>
        )}
      </div>
    </div>
  );
}
