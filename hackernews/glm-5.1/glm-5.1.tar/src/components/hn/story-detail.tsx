'use client';

import { ArrowUp, ExternalLink, MessageSquare, Clock, Bookmark, BookmarkCheck } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { useItem, useFollowed } from '@/hooks/use-hn';
import { useHNStore } from '@/store/hn-store';
import { extractDomain, timeAgo } from '@/lib/hn-api';
import { CommentTree } from './comment-tree';
import { useQueryClient } from '@tanstack/react-query';

interface StoryDetailProps {
  storyId: number | null;
  onClose: () => void;
}

export function StoryDetail({ storyId, onClose }: StoryDetailProps) {
  const { data, isLoading, error } = useItem(storyId);
  const { data: followed } = useFollowed();
  const queryClient = useQueryClient();
  
  const story = data?.item;
  const comments = data?.comments ?? [];
  const hasMore = data?.hasMore ?? false;
  const isFollowed = followed?.some((f) => f.storyId === storyId) ?? false;

  const handleFollow = async () => {
    if (!storyId) return;
    try {
      if (isFollowed) {
        await fetch(`/api/follow?storyId=${storyId}`, { method: 'DELETE' });
      } else {
        await fetch('/api/follow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ storyId, title: story?.title }),
        });
      }
      queryClient.invalidateQueries({ queryKey: ['followed'] });
    } catch (err) {
      console.error('Failed to toggle follow:', err);
    }
  };

  const handleMarkRead = async () => {
    if (!storyId) return;
    try {
      await fetch('/api/follow', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ storyId }),
      });
      queryClient.invalidateQueries({ queryKey: ['followed'] });
    } catch (err) {
      console.error('Failed to mark read:', err);
    }
  };

  return (
    <Sheet open={storyId !== null} onOpenChange={(open) => !open && onClose()}>
      <SheetContent className="w-full sm:max-w-lg md:max-w-2xl p-0 flex flex-col">
        <SheetHeader className="p-4 pb-0">
          <div className="flex items-start justify-between gap-2">
            <SheetTitle className="text-left text-base leading-snug pr-4">
              {story?.title || 'Loading...'}
            </SheetTitle>
          </div>
        </SheetHeader>

        {isLoading && (
          <div className="p-4 space-y-3">
            <div className="flex items-center gap-3">
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-4 w-24" />
            </div>
            <div className="flex gap-2">
              <Skeleton className="h-8 w-28" />
              <Skeleton className="h-8 w-20" />
            </div>
            <Separator />
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="space-y-2" style={{ marginLeft: `${i * 16}px` }}>
                  <Skeleton className="h-3 w-24" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="p-4 text-center text-destructive">
            Failed to load story details
          </div>
        )}

        {story && (
          <>
            {/* Story meta */}
            <div className="px-4 py-2">
              <div className="flex items-center flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                <span className="flex items-center gap-0.5">
                  <ArrowUp className="w-3 h-3 text-orange-500" />
                  {story.score ?? 0} points
                </span>
                <span className="flex items-center gap-0.5">
                  <Clock className="w-3 h-3" />
                  {story.time ? timeAgo(story.time) : 'unknown'}
                </span>
                <span>by <span className="font-medium text-foreground">{story.by}</span></span>
                {story.url && (
                  <a
                    href={story.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-0.5 hover:text-orange-500 transition-colors"
                  >
                    {extractDomain(story.url)}
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 mt-3 flex-wrap">
                {story.url && (
                  <Button size="sm" variant="outline" asChild className="text-xs h-8">
                    <a href={story.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-3.5 h-3.5 mr-1" />
                      Read Article
                    </a>
                  </Button>
                )}
                <Button
                  size="sm"
                  variant={isFollowed ? 'default' : 'outline'}
                  className={`text-xs h-8 ${isFollowed ? 'bg-orange-500 hover:bg-orange-600 text-white' : ''}`}
                  onClick={handleFollow}
                >
                  {isFollowed ? (
                    <>
                      <BookmarkCheck className="w-3.5 h-3.5 mr-1" />
                      Following
                    </>
                  ) : (
                    <>
                      <Bookmark className="w-3.5 h-3.5 mr-1" />
                      Follow
                    </>
                  )}
                </Button>
                {isFollowed && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-xs h-8"
                    onClick={handleMarkRead}
                  >
                    Mark read
                  </Button>
                )}
                <a
                  href={`https://news.ycombinator.com/item?id=${story.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button size="sm" variant="ghost" className="text-xs h-8">
                    View on HN
                  </Button>
                </a>
              </div>

              {/* Story text (for Ask HN, etc.) */}
              {story.text && (
                <div 
                  className="mt-3 text-sm [&_a]:text-orange-500 [&_a]:underline [&_code]:text-orange-500 [&_pre]:bg-muted [&_pre]:rounded [&_pre]:p-2 [&_pre]:text-xs [&_img]:hidden"
                  dangerouslySetInnerHTML={{ __html: story.text }}
                />
              )}
            </div>

            <Separator />

            {/* Comments header */}
            <div className="px-4 py-2 flex items-center justify-between bg-muted/30">
              <span className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5" />
                {story.descendants ?? 0} comments
              </span>
              {hasMore && (
                <a
                  href={`https://news.ycombinator.com/item?id=${story.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[10px] text-orange-500 hover:underline"
                >
                  View all on HN →
                </a>
              )}
            </div>

            {/* Comments */}
            <ScrollArea className="flex-1">
              <div className="px-4 py-2">
                <CommentTree comments={comments} />
                {hasMore && (
                  <div className="text-center py-4">
                    <Button variant="outline" size="sm" asChild className="text-xs">
                      <a href={`https://news.ycombinator.com/item?id=${story.id}`} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        View full discussion on Hacker News
                      </a>
                    </Button>
                  </div>
                )}
              </div>
            </ScrollArea>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
