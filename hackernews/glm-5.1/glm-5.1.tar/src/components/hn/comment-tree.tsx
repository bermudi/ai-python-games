'use client';

import { useState } from 'react';
import { ChevronRight, ChevronDown, User, MessageSquare } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { timeAgo } from '@/lib/hn-api';
import ReactMarkdown from 'react-markdown';

interface CommentNode {
  id: number;
  by?: string;
  time?: number;
  text?: string;
  kids?: number[];
  depth: number;
  children: CommentNode[];
}

interface CommentTreeProps {
  comments: CommentNode[];
}

function CommentItem({ comment }: { comment: CommentNode }) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = comment.children && comment.children.length > 0;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div 
        className="relative"
        style={{ marginLeft: `${Math.min(comment.depth, 12) * 16}px` }}
      >
        {/* Thread line */}
        {comment.depth > 0 && (
          <div 
            className="absolute top-0 bottom-0 w-px bg-border hover:bg-orange-500/50 transition-colors cursor-pointer"
            style={{ left: '-8px' }}
            onClick={() => setIsOpen(!isOpen)}
          />
        )}

        <div className="flex items-start gap-2 py-1">
          {/* Collapse toggle */}
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-5 w-5 p-0 shrink-0 mt-1 hover:bg-orange-500/10"
            >
              {hasChildren ? (
                isOpen ? (
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
                )
              ) : (
                <MessageSquare className="w-3 h-3 text-muted-foreground/50" />
              )}
            </Button>
          </CollapsibleTrigger>

          <div className="flex-1 min-w-0">
            {/* Comment header */}
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-orange-600 dark:text-orange-400">
                {comment.by || '[deleted]'}
              </span>
              <span className="text-muted-foreground">
                {comment.time ? timeAgo(comment.time) : ''}
              </span>
              {!isOpen && hasChildren && (
                <Badge variant="outline" className="text-[10px] px-1 h-4">
                  {comment.children.length} hidden
                </Badge>
              )}
            </div>

            {/* Comment body */}
            <CollapsibleContent>
              <div className="mt-1 text-sm text-foreground/90 prose prose-sm max-w-none dark:prose-invert prose-a:text-orange-500 prose-code:text-orange-500 prose-pre:bg-muted">
                {comment.text ? (
                  <div 
                    dangerouslySetInnerHTML={{ __html: comment.text }}
                    className="[&_a]:text-orange-500 [&_a]:underline [&_code]:text-orange-500 [&_pre]:bg-muted [&_pre]:rounded [&_pre]:p-2 [&_pre]:text-xs [&_img]:hidden"
                  />
                ) : (
                  <span className="text-muted-foreground italic">[deleted]</span>
                )}
              </div>

              {/* Nested comments */}
              {hasChildren && (
                <div className="mt-1">
                  {comment.children.map((child) => (
                    <CommentItem key={child.id} comment={child} />
                  ))}
                </div>
              )}
            </CollapsibleContent>
          </div>
        </div>
      </div>
    </Collapsible>
  );
}

export function CommentTree({ comments }: CommentTreeProps) {
  if (!comments || comments.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No comments yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-0">
      {comments.map((comment) => (
        <CommentItem key={comment.id} comment={comment} />
      ))}
    </div>
  );
}
