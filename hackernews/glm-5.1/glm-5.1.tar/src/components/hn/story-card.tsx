'use client';

import { useState, useCallback } from 'react';
import { MessageSquare, ExternalLink, ArrowUp, Clock, Bookmark, BookmarkCheck, Eye } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useThumbnail, useFollowed } from '@/hooks/use-hn';
import { useHNStore } from '@/store/hn-store';
import { extractDomain, timeAgo } from '@/lib/hn-api';
import { useQueryClient } from '@tanstack/react-query';

interface HNStory {
  id: number;
  type?: string;
  by?: string;
  time?: number;
  text?: string;
  kids?: number[];
  url?: string;
  score?: number;
  title?: string;
  descendants?: number;
}

interface StoryCardProps {
  story: HNStory;
  index: number;
  onSelect: (id: number) => void;
}

function ThumbnailImage({ url }: { url?: string }) {
  const { data, isLoading } = useThumbnail(url);
  const [imgError, setImgError] = useState(false);
  
  const domain = url ? extractDomain(url) : null;

  if (!url) {
    // Text-only post (Ask HN, etc.)
    return (
      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-lg bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center shrink-0">
        <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
      </div>
    );
  }

  // Get domain initials for immediate display
  const domainInitial = domain?.split('.')[0]?.toUpperCase().slice(0, 2) || '?';
  const colors = ['from-rose-400 to-pink-500', 'from-violet-400 to-purple-500', 'from-cyan-400 to-teal-500', 'from-amber-400 to-orange-500', 'from-emerald-400 to-green-500', 'from-sky-400 to-blue-500'];
  const colorIndex = domain ? domain.charCodeAt(0) % colors.length : 0;

  if (isLoading) {
    return (
      <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-lg bg-gradient-to-br ${colors[colorIndex]} flex items-center justify-center shrink-0`}>
        <span className="text-white text-xs font-bold">{domainInitial}</span>
      </div>
    );
  }

  if (data?.imageUrl && !imgError) {
    return (
      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-lg overflow-hidden shrink-0 bg-muted">
        <img
          src={data.imageUrl}
          alt=""
          className="w-full h-full object-cover"
          onError={() => setImgError(true)}
          loading="lazy"
        />
      </div>
    );
  }

  // Fallback: colored domain badge
  return (
    <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-lg bg-gradient-to-br ${colors[colorIndex]} flex items-center justify-center shrink-0`}>
      <span className="text-white text-xs font-bold">{domainInitial}</span>
    </div>
  );
}

export function StoryCard({ story, index, onSelect }: StoryCardProps) {
  const { visitedIds, addVisited } = useHNStore();
  const isVisited = visitedIds.has(story.id);
  const domain = extractDomain(story.url);
  const { data: followed } = useFollowed();
  const isFollowed = followed?.some((f) => f.storyId === story.id) ?? false;
  const queryClient = useQueryClient();

  const handleClick = async () => {
    onSelect(story.id);
    addVisited(story.id);
    // Mark as visited in backend
    fetch('/api/visited', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ storyId: story.id, title: story.title }),
    }).catch(console.error);
  };

  const handleFollow = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      if (isFollowed) {
        await fetch(`/api/follow?storyId=${story.id}`, { method: 'DELETE' });
      } else {
        await fetch('/api/follow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ storyId: story.id, title: story.title }),
        });
      }
      // Invalidate followed queries to refetch
      queryClient.invalidateQueries({ queryKey: ['followed'] });
    } catch (err) {
      console.error('Failed to toggle follow:', err);
    }
  }, [isFollowed, story.id, story.title, queryClient]);

  const handleExternalLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    addVisited(story.id);
    fetch('/api/visited', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ storyId: story.id, title: story.title }),
    }).catch(console.error);
  };

  return (
    <Card 
      className={`group cursor-pointer transition-all hover:shadow-md border-l-2 ${
        isVisited 
          ? 'border-l-muted-foreground/30 opacity-60 hover:opacity-100' 
          : 'border-l-orange-500'
      }`}
      onClick={handleClick}
    >
      <CardContent className="p-3 sm:p-4">
        <div className="flex gap-2 sm:gap-3">
          {/* Rank */}
          <div className="flex flex-col items-center justify-center w-5 shrink-0">
            <span className="text-[11px] font-mono text-muted-foreground">{index + 1}</span>
          </div>

          {/* Thumbnail */}
          <ThumbnailImage url={story.url} />

          {/* Content */}
          <div className="flex-1 min-w-0">
            <h3 className={`text-sm font-medium leading-snug line-clamp-2 ${
              isVisited ? 'text-muted-foreground' : 'text-foreground'
            }`}>
              {story.title}
            </h3>

            {/* Meta row */}
            <div className="flex items-center flex-wrap gap-x-2 sm:gap-x-3 gap-y-0.5 mt-1 text-[11px] sm:text-xs text-muted-foreground">
              <span className="flex items-center gap-0.5">
                <ArrowUp className="w-3 h-3 text-orange-500" />
                {story.score ?? 0}
              </span>
              <span className="flex items-center gap-0.5">
                <Clock className="w-3 h-3" />
                {story.time ? timeAgo(story.time) : 'unknown'}
              </span>
              <span>by <span className="font-medium">{story.by}</span></span>
              {domain && (
                <a
                  href={story.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleExternalLink}
                  className="flex items-center gap-0.5 hover:text-orange-500 transition-colors"
                >
                  {domain}
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
              )}
              <button
                onClick={handleClick}
                className="flex items-center gap-0.5 hover:text-orange-500 transition-colors"
              >
                <MessageSquare className="w-3 h-3" />
                {story.descendants ?? story.kids?.length ?? 0}
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col items-center gap-0.5 shrink-0">
            {isVisited && (
              <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 opacity-40">
                <Eye className="w-2.5 h-2.5 mr-0.5" />
                read
              </Badge>
            )}
            <Button
              variant="ghost"
              size="sm"
              className={`h-7 w-7 p-0 transition-opacity ${
                isFollowed 
                  ? 'text-orange-500 opacity-100' 
                  : 'text-muted-foreground opacity-0 group-hover:opacity-100'
              }`}
              onClick={handleFollow}
              title={isFollowed ? 'Unfollow' : 'Follow comments'}
            >
              {isFollowed ? (
                <BookmarkCheck className="w-4 h-4" />
              ) : (
                <Bookmark className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function StoryCardSkeleton() {
  return (
    <Card>
      <CardContent className="p-3 sm:p-4">
        <div className="flex gap-2 sm:gap-3">
          <Skeleton className="w-5 h-4" />
          <Skeleton className="w-14 h-14 sm:w-16 sm:h-16 rounded-lg" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
