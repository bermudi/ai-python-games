'use client';

import { useQuery } from '@tanstack/react-query';
import { type StoryType } from '@/store/hn-store';

interface HNStory {
  id: number;
  type?: string;
  by?: string;
  time?: number;
  text?: string;
  kids?: number[];
  url?: string;
  score?: number;
  title?: string;
  descendants?: number;
}

interface StoriesResponse {
  stories: HNStory[];
  total: number;
}

export function useStories(type: StoryType, page: number = 1) {
  return useQuery<StoriesResponse>({
    queryKey: ['hn-stories', type, page],
    queryFn: async () => {
      const res = await fetch(`/api/hn/stories?type=${type}&limit=30&page=${page}`);
      if (!res.ok) throw new Error('Failed to fetch stories');
      return res.json();
    },
    staleTime: 60 * 1000,
    refetchInterval: 2 * 60 * 1000,
  });
}

interface CommentNode {
  id: number;
  by?: string;
  time?: number;
  text?: string;
  kids?: number[];
  depth: number;
  children: CommentNode[];
}

interface ItemResponse {
  item: HNStory;
  comments: CommentNode[];
  totalTopLevel: number;
  hasMore: boolean;
}

export function useItem(storyId: number | null) {
  return useQuery<ItemResponse>({
    queryKey: ['hn-item', storyId],
    queryFn: async () => {
      const res = await fetch(`/api/hn/item/${storyId}?limit=20`);
      if (!res.ok) throw new Error('Failed to fetch item');
      return res.json();
    },
    enabled: storyId !== null,
    staleTime: 5 * 60 * 1000,
  });
}

interface ThumbnailData {
  imageUrl: string | null;
  domain: string | null;
  cached: boolean;
}

export function useThumbnail(url: string | undefined) {
  return useQuery<ThumbnailData>({
    queryKey: ['thumbnail', url],
    queryFn: async () => {
      const res = await fetch(`/api/hn/thumbnail?url=${encodeURIComponent(url!)}`);
      if (!res.ok) throw new Error('Failed to fetch thumbnail');
      return res.json();
    },
    enabled: !!url,
    staleTime: 24 * 60 * 60 * 1000,
  });
}

interface VisitedStory {
  id: string;
  storyId: number;
  title: string | null;
  visitedAt: string;
}

export function useVisited() {
  return useQuery<VisitedStory[]>({
    queryKey: ['visited'],
    queryFn: async () => {
      const res = await fetch('/api/visited');
      if (!res.ok) throw new Error('Failed to fetch visited');
      const data = await res.json();
      return data.visited;
    },
    staleTime: 5 * 60 * 1000,
  });
}

interface FollowedStory {
  id: string;
  storyId: number;
  title: string | null;
  lastCommentCount: number;
  followedAt: string;
  lastCheckedAt: string;
  currentCommentCount: number;
  newComments: number;
  score: number;
}

export function useFollowed() {
  return useQuery<FollowedStory[]>({
    queryKey: ['followed'],
    queryFn: async () => {
      const res = await fetch('/api/follow');
      if (!res.ok) throw new Error('Failed to fetch followed');
      const data = await res.json();
      return data.followed;
    },
    staleTime: 60 * 1000,
    refetchInterval: 5 * 60 * 1000,
  });
}
