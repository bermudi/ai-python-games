import { NextRequest, NextResponse } from 'next/server';
import { fetchItem, fetchCommentTree } from '@/lib/hn-api';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const storyId = parseInt(id);
  const commentLimit = Math.min(parseInt(request.nextUrl.searchParams.get('limit') || '20'), 50);
  
  if (isNaN(storyId)) {
    return NextResponse.json({ error: 'Invalid story ID' }, { status: 400 });
  }

  try {
    const item = await fetchItem(storyId);
    if (!item) {
      return NextResponse.json({ error: 'Item not found' }, { status: 404 });
    }

    const totalComments = item.kids?.length ?? 0;
    const comments = item.kids && item.kids.length > 0
      ? await fetchCommentTree(item.kids.slice(0, commentLimit), 0)
      : [];

    return NextResponse.json({ 
      item, 
      comments,
      totalTopLevel: totalComments,
      hasMore: totalComments > commentLimit,
    });
  } catch (error) {
    console.error('Failed to fetch item:', error);
    return NextResponse.json({ error: 'Failed to fetch item' }, { status: 500 });
  }
}
