import { NextRequest, NextResponse } from 'next/server';
import { fetchStoryIds, fetchItems, type StoryType } from '@/lib/hn-api';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const type = (searchParams.get('type') || 'top') as StoryType;
  const limit = Math.min(parseInt(searchParams.get('limit') || '30'), 100);
  const page = parseInt(searchParams.get('page') || '1');
  
  const validTypes: StoryType[] = ['top', 'new', 'best', 'ask', 'show', 'job'];
  if (!validTypes.includes(type)) {
    return NextResponse.json({ error: 'Invalid story type' }, { status: 400 });
  }

  try {
    const allIds = await fetchStoryIds(type, limit * page);
    const idsForPage = allIds.slice((page - 1) * limit, page * limit);
    const stories = await fetchItems(idsForPage);
    
    return NextResponse.json({ stories, total: allIds.length });
  } catch (error) {
    console.error('Failed to fetch stories:', error);
    return NextResponse.json({ error: 'Failed to fetch stories' }, { status: 500 });
  }
}
