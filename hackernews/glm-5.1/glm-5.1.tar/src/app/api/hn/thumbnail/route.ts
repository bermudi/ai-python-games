import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  const url = request.nextUrl.searchParams.get('url');
  
  if (!url) {
    return NextResponse.json({ error: 'URL parameter required' }, { status: 400 });
  }

  try {
    // Check cache first
    const cached = await db.thumbnailCache.findUnique({ where: { url } });
    
    if (cached && cached.imageUrl) {
      // Cache is fresh enough (24 hours)
      const age = Date.now() - cached.fetchedAt.getTime();
      if (age < 24 * 60 * 60 * 1000) {
        return NextResponse.json({ 
          imageUrl: cached.imageUrl, 
          domain: cached.domain,
          cached: true 
        });
      }
    }

    // Extract domain
    let domain = '';
    try {
      domain = new URL(url).hostname.replace(/^www\./, '');
    } catch {
      domain = 'unknown';
    }

    // Try to fetch og:image from the page
    let imageUrl: string | null = null;
    
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      
      const res = await fetch(url, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; HNReader/1.0)',
        },
      });
      clearTimeout(timeout);
      
      if (res.ok) {
        const html = await res.text();
        
        // Try og:image first
        const ogMatch = html.match(/<meta[^>]*property=["']og:image["'][^>]*content=["']([^"']+)["']/i) 
          || html.match(/<meta[^>]*content=["']([^"']+)["'][^>]*property=["']og:image["']/i);
        
        if (ogMatch) {
          imageUrl = ogMatch[1];
          // Handle relative URLs
          if (imageUrl.startsWith('/')) {
            const urlObj = new URL(url);
            imageUrl = `${urlObj.protocol}//${urlObj.host}${imageUrl}`;
          }
        }
        
        // Try twitter:image as fallback
        if (!imageUrl) {
          const twitterMatch = html.match(/<meta[^>]*name=["']twitter:image["'][^>]*content=["']([^"']+)["']/i)
            || html.match(/<meta[^>]*content=["']([^"']+)["'][^>]*name=["']twitter:image["']/i);
          
          if (twitterMatch) {
            imageUrl = twitterMatch[1];
            if (imageUrl.startsWith('/')) {
              const urlObj = new URL(url);
              imageUrl = `${urlObj.protocol}//${urlObj.host}${imageUrl}`;
            }
          }
        }
      }
    } catch {
      // Failed to fetch the page, that's ok
    }

    // Fallback to Google favicon
    if (!imageUrl && domain && domain !== 'unknown') {
      imageUrl = `https://www.google.com/s2/favicons?domain=${domain}&sz=128`;
    }

    // Update cache
    await db.thumbnailCache.upsert({
      where: { url },
      create: { url, imageUrl, domain, fetchedAt: new Date() },
      update: { imageUrl, domain, fetchedAt: new Date() },
    });

    return NextResponse.json({ imageUrl, domain, cached: false });
  } catch (error) {
    console.error('Thumbnail fetch error:', error);
    return NextResponse.json({ imageUrl: null, domain: null, error: 'Failed to fetch thumbnail' }, { status: 500 });
  }
}
