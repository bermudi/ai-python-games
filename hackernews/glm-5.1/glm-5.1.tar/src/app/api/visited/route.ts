import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all visited story IDs
export async function GET() {
  try {
    const visited = await db.visitedStory.findMany({
      orderBy: { visitedAt: 'desc' },
    });
    return NextResponse.json({ visited });
  } catch (error) {
    console.error('Failed to fetch visited:', error);
    return NextResponse.json({ error: 'Failed to fetch visited stories' }, { status: 500 });
  }
}

// POST - mark story as visited
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { storyId, title } = body;
    
    if (!storyId) {
      return NextResponse.json({ error: 'storyId required' }, { status: 400 });
    }

    const visited = await db.visitedStory.upsert({
      where: { storyId },
      create: { storyId, title },
      update: { visitedAt: new Date(), title: title || undefined },
    });

    return NextResponse.json({ visited });
  } catch (error) {
    console.error('Failed to mark visited:', error);
    return NextResponse.json({ error: 'Failed to mark as visited' }, { status: 500 });
  }
}

// DELETE - clear all visited or specific story
export async function DELETE(request: NextRequest) {
  try {
    const storyId = request.nextUrl.searchParams.get('storyId');
    
    if (storyId) {
      await db.visitedStory.deleteMany({ where: { storyId: parseInt(storyId) } });
    } else {
      await db.visitedStory.deleteMany();
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to clear visited:', error);
    return NextResponse.json({ error: 'Failed to clear visited' }, { status: 500 });
  }
}
