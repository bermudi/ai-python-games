import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { fetchItem } from '@/lib/hn-api';

// GET all followed stories
export async function GET() {
  try {
    const followed = await db.followedStory.findMany({
      orderBy: { followedAt: 'desc' },
    });

    // Enrich with current comment counts
    const enriched = await Promise.all(
      followed.map(async (f) => {
        const item = await fetchItem(f.storyId);
        const currentCount = item?.descendants ?? 0;
        const newComments = Math.max(0, currentCount - f.lastCommentCount);
        return {
          ...f,
          currentCommentCount: currentCount,
          newComments,
          score: item?.score ?? 0,
        };
      })
    );

    return NextResponse.json({ followed: enriched });
  } catch (error) {
    console.error('Failed to fetch followed:', error);
    return NextResponse.json({ error: 'Failed to fetch followed stories' }, { status: 500 });
  }
}

// POST - follow a story
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { storyId, title } = body;
    
    if (!storyId) {
      return NextResponse.json({ error: 'storyId required' }, { status: 400 });
    }

    // Get current comment count
    const item = await fetchItem(storyId);
    const commentCount = item?.descendants ?? 0;

    const followed = await db.followedStory.upsert({
      where: { storyId },
      create: { storyId, title, lastCommentCount: commentCount },
      update: { lastCommentCount: commentCount, lastCheckedAt: new Date(), title: title || undefined },
    });

    return NextResponse.json({ followed });
  } catch (error) {
    console.error('Failed to follow story:', error);
    return NextResponse.json({ error: 'Failed to follow story' }, { status: 500 });
  }
}

// DELETE - unfollow a story
export async function DELETE(request: NextRequest) {
  try {
    const storyId = request.nextUrl.searchParams.get('storyId');
    
    if (storyId) {
      await db.followedStory.deleteMany({ where: { storyId: parseInt(storyId) } });
    } else {
      await db.followedStory.deleteMany();
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to unfollow:', error);
    return NextResponse.json({ error: 'Failed to unfollow' }, { status: 500 });
  }
}

// PATCH - update last checked count (mark as read)
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { storyId } = body;
    
    if (!storyId) {
      return NextResponse.json({ error: 'storyId required' }, { status: 400 });
    }

    const item = await fetchItem(storyId);
    const currentCount = item?.descendants ?? 0;

    const updated = await db.followedStory.update({
      where: { storyId },
      data: { lastCommentCount: currentCount, lastCheckedAt: new Date() },
    });

    return NextResponse.json({ followed: updated });
  } catch (error) {
    console.error('Failed to update follow:', error);
    return NextResponse.json({ error: 'Failed to update follow' }, { status: 500 });
  }
}
