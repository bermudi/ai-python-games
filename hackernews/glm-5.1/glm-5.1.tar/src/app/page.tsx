'use client';

import { Header } from '@/components/hn/header';
import { StoryList } from '@/components/hn/story-list';
import { StoryDetail } from '@/components/hn/story-detail';
import { FollowedPanel } from '@/components/hn/followed-panel';
import { useHNStore } from '@/store/hn-store';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState } from 'react';
import { Footer } from '@/components/hn/footer';

function AppContent() {
  const { viewMode, selectedStoryId, setSelectedStoryId } = useHNStore();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 max-w-5xl mx-auto w-full">
        {viewMode === 'stories' ? <StoryList /> : <FollowedPanel />}
      </main>
      <Footer />
      <StoryDetail
        storyId={selectedStoryId}
        onClose={() => setSelectedStoryId(null)}
      />
    </div>
  );
}

export default function Home() {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        retry: 2,
        refetchOnWindowFocus: false,
      },
    },
  }));

  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  );
}
