import { create } from 'zustand';

export type StoryType = 'top' | 'new' | 'best' | 'ask' | 'show' | 'job';

interface HNStore {
  // Story list state
  storyType: StoryType;
  setStoryType: (type: StoryType) => void;
  page: number;
  setPage: (page: number) => void;
  
  // Visited stories
  visitedIds: Set<number>;
  setVisitedIds: (ids: Set<number>) => void;
  addVisited: (id: number) => void;
  
  // Hide visited toggle
  hideVisited: boolean;
  setHideVisited: (hide: boolean) => void;
  
  // Selected story for comments
  selectedStoryId: number | null;
  setSelectedStoryId: (id: number | null) => void;
  
  // View mode
  viewMode: 'stories' | 'followed';
  setViewMode: (mode: 'stories' | 'followed') => void;
  
  // Followed stories with new comment counts
  followedNewComments: Record<number, number>;
  setFollowedNewComments: (data: Record<number, number>) => void;
}

export const useHNStore = create<HNStore>((set) => ({
  storyType: 'top',
  setStoryType: (type) => set({ storyType: type, page: 1 }),
  page: 1,
  setPage: (page) => set({ page }),
  
  visitedIds: new Set<number>(),
  setVisitedIds: (ids) => set({ visitedIds: ids }),
  addVisited: (id) => set((state) => {
    const newSet = new Set(state.visitedIds);
    newSet.add(id);
    return { visitedIds: newSet };
  }),
  
  hideVisited: false,
  setHideVisited: (hide) => set({ hideVisited: hide }),
  
  selectedStoryId: null,
  setSelectedStoryId: (id) => set({ selectedStoryId: id }),
  
  viewMode: 'stories',
  setViewMode: (mode) => set({ viewMode: mode }),
  
  followedNewComments: {},
  setFollowedNewComments: (data) => set({ followedNewComments: data }),
}));
