const HN_API_BASE = 'https://hacker-news.firebaseio.com/v0';

export interface HNItem {
  id: number;
  deleted?: boolean;
  type?: 'job' | 'story' | 'comment' | 'poll' | 'pollopt';
  by?: string;
  time?: number;
  text?: string;
  dead?: boolean;
  parent?: number;
  poll?: number;
  kids?: number[];
  url?: string;
  score?: number;
  title?: string;
  parts?: number[];
  descendants?: number;
}

export type StoryType = 'top' | 'new' | 'best' | 'ask' | 'show' | 'job';

const STORY_ENDPOINTS: Record<StoryType, string> = {
  top: 'topstories',
  new: 'newstories',
  best: 'beststories',
  ask: 'askstories',
  show: 'showstories',
  job: 'jobstories',
};

export async function fetchStoryIds(type: StoryType, limit: number = 30): Promise<number[]> {
  const endpoint = STORY_ENDPOINTS[type];
  const res = await fetch(`${HN_API_BASE}/${endpoint}.json`, {
    next: { revalidate: 60 },
  });
  if (!res.ok) throw new Error(`Failed to fetch ${type} stories`);
  const ids: number[] = await res.json();
  return ids.slice(0, limit);
}

export async function fetchItem(id: number): Promise<HNItem | null> {
  const res = await fetch(`${HN_API_BASE}/item/${id}.json`, {
    next: { revalidate: 300 },
  });
  if (!res.ok) return null;
  const item: HNItem = await res.json();
  return item;
}

export async function fetchItems(ids: number[]): Promise<HNItem[]> {
  const items = await Promise.all(ids.map(fetchItem));
  return items.filter((item): item is HNItem => item !== null && !item.deleted && !item.dead);
}

export async function fetchCommentTree(ids: number[], depth: number = 0): Promise<(HNItem & { children: HNItem[]; depth: number })[]> {
  if (!ids || ids.length === 0 || depth > 10) return [];
  
  const items = await Promise.all(
    ids.map(async (id) => {
      const item = await fetchItem(id);
      if (!item || item.deleted || item.dead) return null;
      
      const children = item.kids && item.kids.length > 0
        ? await fetchCommentTree(item.kids, depth + 1)
        : [];
      
      return { ...item, children, depth };
    })
  );
  
  return items.filter((item): item is HNItem & { children: HNItem[]; depth: number } => item !== null);
}

export function extractDomain(url?: string): string | null {
  if (!url) return null;
  try {
    const hostname = new URL(url).hostname;
    return hostname.replace(/^www\./, '');
  } catch {
    return null;
  }
}

export function timeAgo(timestamp: number): string {
  const seconds = Math.floor(Date.now() / 1000 - timestamp);
  
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo`;
  const years = Math.floor(months / 12);
  return `${years}y`;
}
